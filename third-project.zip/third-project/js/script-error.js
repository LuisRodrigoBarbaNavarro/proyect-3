/*
Rodrigo Barba - Shinia
*/

/**
    * @fileoverview Archivo JS para la página de error
*/
function reback() {
    // Redirige al usuario a la página de inicio de sesión
    window.location.href = "../html/index.html";
}